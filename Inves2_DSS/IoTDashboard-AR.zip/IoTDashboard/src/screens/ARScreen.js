// src/screens/ARScreen.js
// ─────────────────────────────────────────────────────────────────────────────
//  Vista AR — cámara en tiempo real con overlay de datos IoT desde Firebase
// ─────────────────────────────────────────────────────────────────────────────

import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Dimensions,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { SafeAreaView } from 'react-native-safe-area-context';
import useFirebaseIoT from '../hooks/useFirebaseIoT';
import { COLORS, FONTS, SPACING } from '../theme';

const { width, height } = Dimensions.get('window');

// ── HUD flotante por sensor ────────────────────────────────────
function SensorHUD({ label, value, unit, color, style }) {
  return (
    <View style={[styles.hud, { borderColor: color + '88' }, style]}>
      <View style={[styles.hudDot, { backgroundColor: color }]} />
      <View>
        <Text style={[styles.hudLabel, { color }]}>{label}</Text>
        <Text style={styles.hudValue}>
          {value ?? '--'}
          {unit ? <Text style={styles.hudUnit}> {unit}</Text> : null}
        </Text>
      </View>
    </View>
  );
}

// ── Mira decorativa AR ─────────────────────────────────────────
function ARCrosshair() {
  const cx = width / 2, cy = height / 2, s = 55;
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      {/* Esquinas */}
      <View style={[styles.corner, { top: cy - s, left: cx - s, borderTopWidth: 2, borderLeftWidth: 2 }]} />
      <View style={[styles.corner, { top: cy - s, left: cx + s - 20, borderTopWidth: 2, borderRightWidth: 2 }]} />
      <View style={[styles.corner, { top: cy + s - 20, left: cx - s, borderBottomWidth: 2, borderLeftWidth: 2 }]} />
      <View style={[styles.corner, { top: cy + s - 20, left: cx + s - 20, borderBottomWidth: 2, borderRightWidth: 2 }]} />
      {/* Centro */}
      <View style={[styles.centerDot, { top: cy - 3, left: cx - 3 }]} />
    </View>
  );
}

export default function ARScreen({ navigation }) {
  const [permission, requestPermission] = useCameraPermissions();
  const [facing, setFacing] = useState('back');
  const { data, connected, lastUpdate } = useFirebaseIoT();

  const timeStr = lastUpdate
    ? lastUpdate.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    : '--:--:--';

  // ── Sin permiso ────────────────────────────────────────────
  if (!permission?.granted) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.center}>
          <Text style={styles.permIcon}>📷</Text>
          <Text style={styles.permTitle}>ACCESO A CÁMARA</Text>
          <Text style={styles.permText}>
            La vista AR necesita la cámara para superponer datos IoT.
          </Text>
          <TouchableOpacity style={styles.permBtn} onPress={requestPermission}>
            <Text style={styles.permBtnText}>PERMITIR</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text style={[styles.permText, { marginTop: 12, color: COLORS.textMuted }]}>← Volver</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.root}>
      {/* Cámara fondo */}
      <CameraView style={StyleSheet.absoluteFill} facing={facing} />

      {/* Overlay semitransparente */}
      <View style={styles.overlay} pointerEvents="none" />

      {/* Mira AR */}
      <ARCrosshair />

      {/* HUDs de sensores — posicionados en las esquinas */}
      <SensorHUD
        label="TEMPERATURA"
        value={data?.temperatura}
        unit="°C"
        color={COLORS.warning}
        style={styles.hudTL}
      />
      <SensorHUD
        label="HUMEDAD"
        value={data?.humedad}
        unit="%"
        color={COLORS.info}
        style={styles.hudTR}
      />
      <SensorHUD
        label="PRESIÓN"
        value={data?.presion}
        unit="hPa"
        color={COLORS.success}
        style={styles.hudBL}
      />
      <SensorHUD
        label="CPU"
        value={data?.cpu}
        unit="%"
        color={COLORS.error}
        style={styles.hudBR}
      />

      {/* Header flotante */}
      <SafeAreaView style={styles.headerWrap} edges={['top']}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Text style={styles.backText}>◄ BACK</Text>
          </TouchableOpacity>
          <View style={styles.headerCenter}>
            <Text style={styles.headerTitle}>AR · IoT OVERLAY</Text>
            <View style={styles.connRow}>
              <View style={[styles.connDot, { backgroundColor: connected ? COLORS.success : COLORS.error }]} />
              <Text style={styles.connText}>{connected ? 'FIREBASE LIVE' : 'SIN SEÑAL'}</Text>
              <Text style={styles.connTime}>{timeStr}</Text>
            </View>
          </View>
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => setFacing(f => f === 'back' ? 'front' : 'back')}
          >
            <Text style={styles.backText}>⇄ FLIP</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>

      {/* Etiqueta inferior */}
      <View style={styles.bottomLabel} pointerEvents="none">
        <Text style={styles.bottomText}>▸ AR MODE · FIREBASE REALTIME · 5s ◂</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  safe: { flex: 1, backgroundColor: COLORS.bg },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(10,10,15,0.22)',
  },

  // Header
  headerWrap: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    backgroundColor: 'rgba(10,10,15,0.78)',
    borderBottomWidth: 0.5,
    borderBottomColor: COLORS.border,
  },
  headerCenter: { alignItems: 'center' },
  headerTitle: { fontFamily: FONTS.mono, fontSize: 11, color: COLORS.accent, letterSpacing: 2 },
  connRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  connDot: { width: 5, height: 5, borderRadius: 3 },
  connText: { fontFamily: FONTS.mono, fontSize: 8, color: COLORS.textMuted, letterSpacing: 1 },
  connTime: { fontFamily: FONTS.mono, fontSize: 8, color: COLORS.accent },

  backBtn: { padding: 6 },
  backText: { fontFamily: FONTS.mono, fontSize: 11, color: COLORS.textMuted },

  // HUDs
  hud: {
    position: 'absolute',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    backgroundColor: 'rgba(10,10,15,0.82)',
    borderWidth: 0.5,
    borderRadius: 6,
    padding: SPACING.sm,
    minWidth: 120,
  },
  hudDot:   { width: 5, height: 5, borderRadius: 3 },
  hudLabel: { fontFamily: FONTS.mono, fontSize: 8, letterSpacing: 1.5 },
  hudValue: { fontFamily: FONTS.mono, fontSize: 22, color: COLORS.text },
  hudUnit:  { fontFamily: FONTS.mono, fontSize: 10, color: COLORS.textMuted },

  hudTL: { top: 140, left: 16 },
  hudTR: { top: 140, right: 16 },
  hudBL: { bottom: 100, left: 16 },
  hudBR: { bottom: 100, right: 16 },

  // Crosshair
  corner: {
    position: 'absolute',
    width: 20,
    height: 20,
    borderColor: COLORS.accent + 'bb',
  },
  centerDot: {
    position: 'absolute',
    width: 6, height: 6, borderRadius: 3,
    backgroundColor: COLORS.accent + 'cc',
  },

  // Bottom label
  bottomLabel: {
    position: 'absolute',
    bottom: 50,
    alignSelf: 'center',
  },
  bottomText: {
    fontFamily: FONTS.mono, fontSize: 9,
    color: COLORS.accent + 'bb', letterSpacing: 2,
  },

  // Permiso
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: SPACING.xl, gap: SPACING.md },
  permIcon: { fontSize: 50 },
  permTitle: { fontFamily: FONTS.mono, fontSize: 18, color: COLORS.text, letterSpacing: 2 },
  permText:  { fontFamily: FONTS.mono, fontSize: 12, color: COLORS.textMuted, textAlign: 'center', lineHeight: 20 },
  permBtn: {
    borderWidth: 0.5, borderColor: COLORS.accent,
    borderRadius: 8, paddingHorizontal: SPACING.lg, paddingVertical: SPACING.sm,
  },
  permBtnText: { fontFamily: FONTS.mono, color: COLORS.accent, fontSize: 12, letterSpacing: 2 },
});
