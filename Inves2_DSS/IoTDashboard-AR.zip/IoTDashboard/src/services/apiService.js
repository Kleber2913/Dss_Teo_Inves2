// src/services/apiService.js
import axios from 'axios';

// ─── Configuración base ────────────────────────────────────────────────────
const BASE_URL = 'https://jsonplaceholder.typicode.com'; // Demo público
// Cambia esto por tu endpoint real:  'https://api.tuservidor.io/v1'

const TOKEN = 'TU_TOKEN_AQUI'; // Bearer token si tu API lo requiere

// ══════════════════════════════════════════════════════════════════════════════
//  OPCIÓN 1 — fetch nativo
// ══════════════════════════════════════════════════════════════════════════════
export const fetchIoTData = async (endpoint, options = {}) => {
  const response = await fetch(`${BASE_URL}${endpoint}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      // 'Authorization': `Bearer ${TOKEN}`,  // Descomenta si usas auth
    },
    ...options, // Permite pasar signal de AbortController
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }

  return response.json();
};

// ══════════════════════════════════════════════════════════════════════════════
//  OPCIÓN 2 — axios (más features: interceptores, timeout, retry)
// ══════════════════════════════════════════════════════════════════════════════
const apiClient = axios.create({
  baseURL: BASE_URL,
  timeout: 4000, // Cancela si tarda más de 4s
  headers: {
    'Content-Type': 'application/json',
    // 'Authorization': `Bearer ${TOKEN}`,
  },
});

// Interceptor de request — útil para logs o añadir tokens dinámicos
apiClient.interceptors.request.use(
  (config) => {
    // config.headers.Authorization = `Bearer ${getToken()}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor de response — manejo global de errores
apiClient.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response) {
      throw new Error(`Error ${error.response.status}: ${error.response.statusText}`);
    } else if (error.request) {
      throw new Error('Sin respuesta del servidor');
    } else {
      throw new Error(error.message);
    }
  }
);

export const fetchIoTAxios = async (endpoint, signal) => {
  return apiClient.get(endpoint, { signal });
};

export default apiClient;
