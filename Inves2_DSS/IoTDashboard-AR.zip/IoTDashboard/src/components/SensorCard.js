// src/components/SensorCard.jsx
// ─────────────────────────────────────────────────────────────
//  Tarjeta individual de sensor IoT
//  Props:
//    label   (string)  — nombre del sensor
//    value   (number)  — valor actual
//    unit    (string)  — ej: "°C", "%", "lux"
//    icon    (string)  — emoji o ícono de texto
//    status  ('ok' | 'warn' | 'alert')
// ─────────────────────────────────────────────────────────────

import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { colors, fonts, spacing, radius } from '../config/theme';

const STATUS_COLORS = {
  ok:    colors.green,
  warn:  colors.amber,
  alert: colors.red,
};

export default function SensorCard({ label, value, unit, icon, status = 'ok' }) {
  const pulse = useRef(new Animated.Value(1)).current;

  // Pulsar cuando el valor cambia
  useEffect(() => {
    Animated.sequence([
      Animated.timing(pulse, { toValue: 1.05, duration: 150, useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 1,    duration: 150, useNativeDriver: true }),
    ]).start();
  }, [value]);

  const accentColor = STATUS_COLORS[status];

  return (
    <Animated.View style={[styles.card, { borderColor: accentColor + '55', transform: [{ scale: pulse }] }]}>
      {/* Línea de acento superior */}
      <View style={[styles.accentLine, { backgroundColor: accentColor }]} />

      <View style={styles.row}>
        <Text style={styles.icon}>{icon}</Text>
        <View style={styles.info}>
          <Text style={styles.label}>{label.toUpperCase()}</Text>
          <View style={styles.valueRow}>
            <Text style={[styles.value, { color: accentColor }]}>
              {value !== null && value !== undefined ? value : '--'}
            </Text>
            <Text style={styles.unit}>{unit}</Text>
          </View>
        </View>

        {/* Indicador de estado */}
        <View style={[styles.dot, { backgroundColor: accentColor }]} />
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.bgCard,
    borderWidth: 1,
    borderRadius: radius.md,
    marginBottom: spacing.sm,
    overflow: 'hidden',
  },
  accentLine: {
    height: 2,
    width: '100%',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    gap: spacing.md,
  },
  icon: {
    fontSize: 28,
  },
  info: {
    flex: 1,
  },
  label: {
    fontFamily: fonts.mono,
    fontSize: 10,
    color: colors.textMuted,
    letterSpacing: 2,
    marginBottom: 4,
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 4,
  },
  value: {
    fontFamily: fonts.title,
    fontSize: 32,
    lineHeight: 36,
  },
  unit: {
    fontFamily: fonts.mono,
    fontSize: 13,
    color: colors.textMuted,
    marginBottom: 4,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
});
