// src/components/ConnectionStatus.jsx
// ─────────────────────────────────────────────────────────────
//  Barra de estado: última actualización + indicador Firebase
// ─────────────────────────────────────────────────────────────

import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { colors, fonts, spacing } from '../config/theme';

export default function ConnectionStatus({ lastUpdate, error }) {
  const blink = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(blink, { toValue: 0.2, duration: 800, useNativeDriver: true }),
        Animated.timing(blink, { toValue: 1,   duration: 800, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const formatTime = (date) => {
    if (!date) return '--:--:--';
    return date.toLocaleTimeString('es-SV', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const isOnline = !error;

  return (
    <View style={styles.bar}>
      <Animated.View style={[styles.dot, { backgroundColor: isOnline ? colors.green : colors.red, opacity: blink }]} />
      <Text style={[styles.text, { color: isOnline ? colors.green : colors.red }]}>
        {isOnline ? 'FIREBASE ONLINE' : 'SIN CONEXIÓN'}
      </Text>
      <Text style={styles.divider}>|</Text>
      <Text style={styles.text}>
        ACTUALIZADO: <Text style={styles.time}>{formatTime(lastUpdate)}</Text>
      </Text>
      <Text style={styles.divider}>|</Text>
      <Text style={styles.text}>POLL: 5s</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    backgroundColor: colors.bgCardAlt,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  text: {
    fontFamily: fonts.mono,
    fontSize: 9,
    color: colors.textMuted,
    letterSpacing: 1,
  },
  time: {
    color: colors.cyan,
  },
  divider: {
    color: colors.textDim,
    fontSize: 10,
  },
});
