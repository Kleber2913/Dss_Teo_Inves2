// src/config/firebase.js
// ─────────────────────────────────────────────────────────────────────────────
//  PASO 1: Ve a https://console.firebase.google.com
//  PASO 2: Crea un proyecto → Realtime Database → Obtén la configuración
//  PASO 3: Pega tus credenciales aquí
// ─────────────────────────────────────────────────────────────────────────────

import { initializeApp, getApps } from 'firebase/app';
import { getDatabase }            from 'firebase/database';

const firebaseConfig = {
  apiKey:            'TU_API_KEY',
  authDomain:        'TU_PROYECTO.firebaseapp.com',
  databaseURL:       'https://TU_PROYECTO-default-rtdb.firebaseio.com',
  projectId:         'TU_PROYECTO',
  storageBucket:     'TU_PROYECTO.appspot.com',
  messagingSenderId: 'TU_SENDER_ID',
  appId:             'TU_APP_ID',
};

// Evita inicializar más de una vez (hot-reload de Expo)
const app = getApps().length === 0
  ? initializeApp(firebaseConfig)
  : getApps()[0];

export const db = getDatabase(app);
export default app;
