-- ============================================
--  BASE DE DATOS: api_productos
--  Ejecutar este script en MySQL/phpMyAdmin
-- ============================================

CREATE DATABASE IF NOT EXISTS api_productos
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE api_productos;

CREATE TABLE IF NOT EXISTS productos (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  nombre    VARCHAR(100)   NOT NULL,
  precio    DECIMAL(10,2)  NOT NULL,
  cantidad  INT            NOT NULL DEFAULT 0,
  creado_en TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
);

-- Datos de ejemplo
INSERT INTO productos (nombre, precio, cantidad) VALUES
  ('Laptop Dell Inspiron',  599.99, 10),
  ('Mouse Inalámbrico',      15.50, 50),
  ('Teclado Mecánico',       45.00, 30),
  ('Monitor 24"',           189.99,  8),
  ('Audífonos Bluetooth',    35.75, 20);
