<?php
// ============================================
//  api.php  –  API REST de Productos
//  GET  /api.php          → listar productos
//  GET  /api.php?id=N     → obtener uno
//  POST /api.php          → insertar producto
// ============================================

require_once 'config.php';

// --- Cabeceras CORS + JSON ---
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Preflight OPTIONS (CORS)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$metodo = $_SERVER['REQUEST_METHOD'];
$conn   = conectarDB();

// ================================================
//  GET  –  Consultar productos
// ================================================
if ($metodo === 'GET') {

    // GET /api.php?id=5  →  un solo producto
    if (isset($_GET['id'])) {
        $id   = (int) $_GET['id'];
        $stmt = $conn->prepare(
            'SELECT id, nombre, precio, cantidad, creado_en
               FROM productos WHERE id = ?'
        );
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows === 0) {
            http_response_code(404);
            echo json_encode(['error' => true, 'mensaje' => 'Producto no encontrado']);
        } else {
            $producto = $resultado->fetch_assoc();
            echo json_encode(['error' => false, 'data' => $producto]);
        }

        $stmt->close();

    // GET /api.php  →  todos los productos
    } else {
        $resultado = $conn->query(
            'SELECT id, nombre, precio, cantidad, creado_en
               FROM productos ORDER BY id DESC'
        );

        $productos = [];
        while ($fila = $resultado->fetch_assoc()) {
            $productos[] = $fila;
        }

        echo json_encode([
            'error' => false,
            'total' => count($productos),
            'data'  => $productos
        ]);
    }

// ================================================
//  POST  –  Insertar nuevo producto
// ================================================
} elseif ($metodo === 'POST') {

    // Leer body JSON
    $body = json_decode(file_get_contents('php://input'), true);

    // Validar campos requeridos
    $nombre   = trim($body['nombre']   ?? '');
    $precio   = $body['precio']   ?? null;
    $cantidad = $body['cantidad'] ?? null;

    if ($nombre === '' || $precio === null || $cantidad === null) {
        http_response_code(400);
        echo json_encode([
            'error'   => true,
            'mensaje' => 'Campos requeridos: nombre, precio, cantidad'
        ]);
        $conn->close();
        exit;
    }

    if (!is_numeric($precio) || $precio < 0) {
        http_response_code(400);
        echo json_encode(['error' => true, 'mensaje' => 'El precio debe ser un número positivo']);
        $conn->close();
        exit;
    }

    if (!is_numeric($cantidad) || $cantidad < 0) {
        http_response_code(400);
        echo json_encode(['error' => true, 'mensaje' => 'La cantidad debe ser un entero positivo']);
        $conn->close();
        exit;
    }

    $stmt = $conn->prepare(
        'INSERT INTO productos (nombre, precio, cantidad) VALUES (?, ?, ?)'
    );
    $stmt->bind_param('sdi', $nombre, $precio, $cantidad);

    if ($stmt->execute()) {
        $nuevoId = $conn->insert_id;
        http_response_code(201);
        echo json_encode([
            'error'   => false,
            'mensaje' => 'Producto creado exitosamente',
            'data'    => [
                'id'       => $nuevoId,
                'nombre'   => $nombre,
                'precio'   => (float) $precio,
                'cantidad' => (int) $cantidad
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => true, 'mensaje' => 'Error al insertar: ' . $stmt->error]);
    }

    $stmt->close();

// ================================================
//  Método no permitido
// ================================================
} else {
    http_response_code(405);
    echo json_encode(['error' => true, 'mensaje' => 'Método no permitido. Use GET o POST.']);
}

$conn->close();
